#######################################################################
## CLOCK (100 MHz Oscillator on Nexys4-DDR)
#######################################################################

set_property PACKAGE_PIN E3 [get_ports clk]
set_property IOSTANDARD LVCMOS33 [get_ports clk]
create_clock -name sys_clk_pin -period 10.0 [get_ports clk]


#######################################################################
## INPUTS
#######################################################################

# Reset (active low)
set_property PACKAGE_PIN H6 [get_ports reset_n]
set_property IOSTANDARD LVCMOS33 [get_ports reset_n]

# Car detection input
set_property PACKAGE_PIN J15 [get_ports car_side]
set_property IOSTANDARD LVCMOS33 [get_ports car_side]


#######################################################################
## TRAFFIC LIGHT OUTPUTS
#######################################################################

# Main Road Lights
set_property PACKAGE_PIN T15 [get_ports MG]
set_property IOSTANDARD LVCMOS33 [get_ports MG]

set_property PACKAGE_PIN T16 [get_ports MY]
set_property IOSTANDARD LVCMOS33 [get_ports MY]

set_property PACKAGE_PIN U14 [get_ports MR]
set_property IOSTANDARD LVCMOS33 [get_ports MR]

# Side Road Lights
set_property PACKAGE_PIN V14 [get_ports SG]
set_property IOSTANDARD LVCMOS33 [get_ports SG]

set_property PACKAGE_PIN V11 [get_ports SY]
set_property IOSTANDARD LVCMOS33 [get_ports SY]

set_property PACKAGE_PIN V12 [get_ports SR]
set_property IOSTANDARD LVCMOS33 [get_ports SR]


#######################################################################
## DEBUG: FSM STATE ? LEDs (LD0-LD1)
#######################################################################

# state[0] ? LED0
set_property PACKAGE_PIN U16 [get_ports {state[0]}]
# state[1] ? LED1
set_property PACKAGE_PIN E19 [get_ports {state[1]}]

set_property IOSTANDARD LVCMOS33 [get_ports {state[*]}]


#######################################################################
## OPTIONAL: next_state ? LEDs (LD2-LD3)
#######################################################################

# next_state[0] ? LED2
set_property PACKAGE_PIN U19 [get_ports {next_state[0]}]
# next_state[1] ? LED3
set_property PACKAGE_PIN V19 [get_ports {next_state[1]}]

set_property IOSTANDARD LVCMOS33 [get_ports {next_state[*]}]


#######################################################################
## TIMER DONE ? ONE LED BLINKS EACH SECOND (LD4)
#######################################################################

# timer_done ? LED4
set_property PACKAGE_PIN W18 [get_ports timer_done]
set_property IOSTANDARD LVCMOS33 [get_ports timer_done]
