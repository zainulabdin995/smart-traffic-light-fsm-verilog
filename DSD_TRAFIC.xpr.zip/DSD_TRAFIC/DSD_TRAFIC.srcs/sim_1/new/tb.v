// ===================== Testbench =====================
`timescale 1ns/1ps
module tb;

reg clk = 0;
reg reset_n = 0;
reg car = 0;

wire MG, MY, MR;
wire SG, SY, SR;
wire [7:0] timer_value;
wire [1:0] state;
wire [1:0] next_state;

top_traffic dut(
    .clk(clk),
    .reset_n(reset_n),
    .car_side(car),
    .MG(MG), .MY(MY), .MR(MR),
    .SG(SG), .SY(SY), .SR(SR),
    .timer_value(timer_value),
    .state(state),
    .next_state(next_state)
);

always #5 clk = ~clk;

initial begin
    $display("TIME | Curr | Next | MG MY MR | SG SY SR | Timer | Car");
    #20 reset_n = 1;
    #200 car = 1;
    #500 car = 0;
    #2000 $finish;
end

always @(posedge clk) begin
    $display("%4t |  %b    %b  | %b  %b  %b | %b  %b  %b | %d | %b",
        $time,
        state, next_state,
        MG, MY, MR,
        SG, SY, SR,
        timer_value,
        car
    );
end

endmodule