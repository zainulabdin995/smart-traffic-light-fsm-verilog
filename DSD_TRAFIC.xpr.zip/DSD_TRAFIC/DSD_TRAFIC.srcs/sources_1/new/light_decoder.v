// ===================== Light Decoder =====================
`timescale 1ns/1ps
module light_decoder (
    input  wire [1:0] state,
    output reg MG, MY, MR,
    output reg SG, SY, SR
);

localparam S1 = 2'b00;
localparam S2 = 2'b01;
localparam S3 = 2'b10;
localparam S4 = 2'b11;

always @(*) begin
    MG = 0; MY = 0; MR = 0;
    SG = 0; SY = 0; SR = 0;

    case (state)
        S1: begin MG=1; SR=1; end
        S2: begin MY=1; SR=1; end
        S3: begin MR=1; SG=1; end
        S4: begin MR=1; SY=1; end
    endcase
end

endmodule