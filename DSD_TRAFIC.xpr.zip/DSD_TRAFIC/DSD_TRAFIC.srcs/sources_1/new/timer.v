// ===================== Timer =====================
`timescale 1ns/1ps
module timer (
    input  wire       clk,
    input  wire       reset_n,
    input  wire [1:0] state,
    output reg        timer_done,
    output reg [7:0]  timer_value
);

localparam T1 = 9;
localparam T2 = 4;
localparam T3 = 7;
localparam T4 = 4;

reg [7:0] counter = 0;
reg [7:0] target  = T1;

always @(posedge clk or negedge reset_n) begin
    if (!reset_n) begin
        counter     <= 0;
        timer_done  <= 0;
        target      <= T1;
        timer_value <= 0;
    end
    else begin
        case (state)
            2'b00: target <= T1;
            2'b01: target <= T2;
            2'b10: target <= T3;
            2'b11: target <= T4;
        endcase

        if (counter >= target) begin
            timer_done <= 1;
            counter    <= 0;
        end
        else begin
            timer_done <= 0;
            counter    <= counter + 1;
        end

        timer_value <= counter;
    end
end

endmodule
