// ===================== Top Module =====================
`timescale 1ns/1ps
module top_traffic (
    input  wire clk,
    input  wire reset_n,
    input  wire car_side,
    output wire MG, MY, MR,
    output wire SG, SY, SR,
    output wire [7:0] timer_value,
    output wire [1:0] state,
    output wire [1:0] next_state
);
wire timer_done; 
traffic_fsm fsm_inst(
    .clk(clk),
    .reset_n(reset_n),
    .car_side(car_side),
    .timer_done(timer_done),
    .state(state),
    .next_state(next_state)
);

timer timer_inst(
    .clk(clk),
    .reset_n(reset_n),
    .state(state),
    .timer_done(timer_done),
    .timer_value(timer_value)
);

light_decoder light_inst(
    .state(state),
    .MG(MG), .MY(MY), .MR(MR),
    .SG(SG), .SY(SY), .SR(SR)
);

endmodule