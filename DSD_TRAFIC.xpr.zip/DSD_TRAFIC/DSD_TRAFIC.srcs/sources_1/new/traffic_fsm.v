`timescale 1ns/1ps

// ===================== Traffic FSM =====================
module traffic_fsm (
    input  wire       clk,
    input  wire       reset_n,
    input  wire       car_side,
    input  wire       timer_done,
    output reg  [1:0] state,
    output reg  [1:0] next_state
);

// State encoding
localparam S1 = 2'b00;   // Main GREEN , Side RED
localparam S2 = 2'b01;   // Main YELLOW, Side RED
localparam S3 = 2'b10;   // Main RED   , Side GREEN
localparam S4 = 2'b11;   // Main RED   , Side YELLOW

always @(*) begin
    case (state)
        S1: next_state = (timer_done && car_side) ? S2 : S1;
        S2: next_state = timer_done ? S3 : S2;
        S3: next_state = timer_done ? S4 : S3;
        S4: next_state = timer_done ? S1 : S4;
        default: next_state = S1;
    endcase
end

always @(posedge clk or negedge reset_n) begin
    if (!reset_n)
        state <= S1;
    else
        state <= next_state;
end

endmodule